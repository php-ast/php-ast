from php_ast import php_ast

php= php_ast.php_ast()

php.get_ast(b"<?php echo 'hello world';")
php.get_ast(b"<?php echo 'hello world';")